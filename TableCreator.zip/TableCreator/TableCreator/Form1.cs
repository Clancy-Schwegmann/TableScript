﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TableCreator
{
    public partial class tableScriptForm : Form
    {
        public tableScriptForm()
        {
            InitializeComponent();
        }

        private void calcBtn_Click(object sender, EventArgs e)
        {
            List<string> outputList = new List<string>();
            string outputText = "";
            double startNum = Int32.Parse(startingTxt.Text);
            double incrementNum = Int32.Parse(incrementTxt.Text);
            double finalNum = Int32.Parse(finalNumTxt.Text);


            while (startNum != (finalNum + incrementNum))
            {
                outputList.Add(startNum.ToString());
                startNum += incrementNum;

                if (Math.Abs(startNum) > Math.Abs(finalNum + incrementNum))
                {
                    
                    MessageBox.Show("Error, array list is out of bounds. You must change one or more of the values you provided.");
                    return;
                }
                //If starting number goes beyond the absolute value of a final number as it is incremented, then return an error
            }          
            
            //Combine all array numbers into one string.
            outputText = string.Join(",", outputList);

            //Add all the items into the system's clipboard.
            try
            {
                System.Windows.Forms.Clipboard.SetText(outputText);
            }
            catch (System.ArgumentNullException)
            {

            }
        }

        private void calcBtn2_Click(object sender, EventArgs e)
        {
            List<string> outputList = new List<string>();
            string outputText = "";
            double startNum = Int32.Parse(startingTxt2.Text);
            double incrementNum = Int32.Parse(incrementTxt2.Text);
            double countNum = Int32.Parse(countTxt.Text);

            countNum--;
            while (countNum >= 0)
            {
                outputList.Add(startNum.ToString());
                startNum += incrementNum;
                countNum--;
            }
            
            //Combine all array numbers into one string.
            outputText = string.Join(",", outputList);

            //Add all the items into the system's clipboard.
            try
            {
                System.Windows.Forms.Clipboard.SetText(outputText);
            }
            catch (System.ArgumentNullException)
            {

            }
        }

        private void helpBtn_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This is TableScript! You can use this program to generate a series of numbers to be used in arrays or spreadsheets!" +
                "\n\n HOW TO USE: There are two boxes which have a series of options to create a list of numbers, then these numbers will be copied into your clipboard to paste somewhere else like a word document. I will explain how to use each box seperately." +
                "\n\n Increment to Counter: This is the very top box, so let's say you want to generate a list of numbers from 1 to 100. Well the process is simple, click on the \"starting number\" text box, delete any text that is in the textbox already and enter 1 as your first input, you can then press the \"Tab\" key on your keyboard to move to the next item. So for \"Increment By\" we can put 1 because we want to include every number from 1 to 100. Lastly, press tab and then type 100 and then press the \"Copy result to clipboard\"  button in the box to copy that list of numbers. You should now have numbers 1 through 100 stored in your clipboard and ready to paste with the Ctrl-V command or your pasting tool of choice." +
                "\n\n Increment to Number: This is the bottom box, like last time you will want to pick a starting number and amount you want to increment by but this time around you want to pay attention to the number you are going towards so let's say you want to go from 8 to 64 and increment by 4 each time. In this case you just want to put 64 as the final number, Increment by 4, and 8 as the starting number.");
        }

        private void tableScriptForm_Load(object sender, EventArgs e)
        {
            ActiveControl = startingTxt2; //Set starting index to the very first text box.
        }
    }
}
