﻿
namespace TableCreator
{
    partial class tableScriptForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.startingTxt = new System.Windows.Forms.NumericUpDown();
            this.finalNumTxt = new System.Windows.Forms.NumericUpDown();
            this.calcBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.helpBtn = new System.Windows.Forms.Button();
            this.incrementTxt = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.countTxt = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.startingTxt2 = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.incrementTxt2 = new System.Windows.Forms.NumericUpDown();
            this.calcBtn2 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.startingTxt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalNumTxt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.incrementTxt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.countTxt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.startingTxt2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.incrementTxt2)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // startingTxt
            // 
            this.startingTxt.Location = new System.Drawing.Point(109, 24);
            this.startingTxt.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.startingTxt.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.startingTxt.Name = "startingTxt";
            this.startingTxt.Size = new System.Drawing.Size(120, 20);
            this.startingTxt.TabIndex = 5;
            this.startingTxt.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            // 
            // finalNumTxt
            // 
            this.finalNumTxt.Location = new System.Drawing.Point(109, 76);
            this.finalNumTxt.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.finalNumTxt.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.finalNumTxt.Name = "finalNumTxt";
            this.finalNumTxt.Size = new System.Drawing.Size(120, 20);
            this.finalNumTxt.TabIndex = 7;
            this.finalNumTxt.Value = new decimal(new int[] {
            64,
            0,
            0,
            0});
            // 
            // calcBtn
            // 
            this.calcBtn.Location = new System.Drawing.Point(54, 102);
            this.calcBtn.Name = "calcBtn";
            this.calcBtn.Size = new System.Drawing.Size(136, 23);
            this.calcBtn.TabIndex = 8;
            this.calcBtn.Text = "Copy result to clipboard";
            this.calcBtn.UseVisualStyleBackColor = true;
            this.calcBtn.Click += new System.EventHandler(this.calcBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Starting Number:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Final Number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Increment Count:";
            // 
            // helpBtn
            // 
            this.helpBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.helpBtn.Location = new System.Drawing.Point(116, 343);
            this.helpBtn.Name = "helpBtn";
            this.helpBtn.Size = new System.Drawing.Size(46, 30);
            this.helpBtn.TabIndex = 9;
            this.helpBtn.Text = "?";
            this.helpBtn.UseVisualStyleBackColor = true;
            this.helpBtn.Click += new System.EventHandler(this.helpBtn_Click);
            // 
            // incrementTxt
            // 
            this.incrementTxt.Location = new System.Drawing.Point(109, 50);
            this.incrementTxt.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.incrementTxt.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.incrementTxt.Name = "incrementTxt";
            this.incrementTxt.Size = new System.Drawing.Size(120, 20);
            this.incrementTxt.TabIndex = 6;
            this.incrementTxt.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 50);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Increment by:";
            // 
            // countTxt
            // 
            this.countTxt.Location = new System.Drawing.Point(109, 80);
            this.countTxt.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.countTxt.Name = "countTxt";
            this.countTxt.Size = new System.Drawing.Size(120, 20);
            this.countTxt.TabIndex = 3;
            this.countTxt.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 13);
            this.label5.TabIndex = 16;
            this.label5.Text = "Starting Number:";
            // 
            // startingTxt2
            // 
            this.startingTxt2.Location = new System.Drawing.Point(109, 28);
            this.startingTxt2.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.startingTxt2.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.startingTxt2.Name = "startingTxt2";
            this.startingTxt2.Size = new System.Drawing.Size(120, 20);
            this.startingTxt2.TabIndex = 1;
            this.startingTxt2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(30, 54);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 13);
            this.label6.TabIndex = 18;
            this.label6.Text = "Increment by:";
            // 
            // incrementTxt2
            // 
            this.incrementTxt2.Location = new System.Drawing.Point(109, 54);
            this.incrementTxt2.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.incrementTxt2.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.incrementTxt2.Name = "incrementTxt2";
            this.incrementTxt2.Size = new System.Drawing.Size(120, 20);
            this.incrementTxt2.TabIndex = 2;
            this.incrementTxt2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // calcBtn2
            // 
            this.calcBtn2.Location = new System.Drawing.Point(54, 106);
            this.calcBtn2.Name = "calcBtn2";
            this.calcBtn2.Size = new System.Drawing.Size(136, 23);
            this.calcBtn2.TabIndex = 4;
            this.calcBtn2.Text = "Copy result to clipboard";
            this.calcBtn2.UseVisualStyleBackColor = true;
            this.calcBtn2.Click += new System.EventHandler(this.calcBtn2_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.startingTxt);
            this.groupBox1.Controls.Add(this.finalNumTxt);
            this.groupBox1.Controls.Add(this.calcBtn);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.incrementTxt);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(11, 192);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(257, 145);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Increment To Number";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.calcBtn2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.countTxt);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.startingTxt2);
            this.groupBox2.Controls.Add(this.incrementTxt2);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Location = new System.Drawing.Point(11, 25);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(257, 151);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Increment to Counter";
            // 
            // tableScriptForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(279, 375);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.helpBtn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "tableScriptForm";
            this.Text = "TableScript";
            this.Load += new System.EventHandler(this.tableScriptForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.startingTxt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.finalNumTxt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.incrementTxt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.countTxt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.startingTxt2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.incrementTxt2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.NumericUpDown startingTxt;
        private System.Windows.Forms.NumericUpDown finalNumTxt;
        private System.Windows.Forms.Button calcBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button helpBtn;
        private System.Windows.Forms.NumericUpDown incrementTxt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown countTxt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown startingTxt2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown incrementTxt2;
        private System.Windows.Forms.Button calcBtn2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}

